# 2024-04-08-build-rag-with-typescript

[![Watch the video](https://img.youtube.com/vi/8rz9axIzIy4/maxresdefault.jpg)](https://youtu.be/8rz9axIzIy4)

1. Install dependencies: `npm install`.
2. Run Chroma on a separate terminal: `chroma run --host localhost --port 8000 --path ./my_chroma_data`
 
